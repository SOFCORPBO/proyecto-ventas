<?php
// Importar variables globales
global $db, $sistema;

// Ejemplo de uso de $db
$resultados = $db->SQL("SELECT * FROM moneda");
while($fila = $resultados->fetch_assoc()) {
    echo $fila['moneda'] . "<br>";
}

// Ejecutar métodos del módulo Sistema según acción del formulario
if(isset($_POST['EditarMoneda'])){
    $sistema->EditarMoneda();
}

if(isset($_POST['CambiarLogo'])){
    $sistema->CambiarLogo();
}

if(isset($_POST['CambiarTema'])){
    $sistema->CambiarTema();
}

if(isset($_POST['ActivarTipoDeCambio'])){
    $sistema->ActivarTipoDeCambio();
}

if(isset($_POST['DesactivarTipoDeCambio'])){
    $sistema->DesactivarTipoDeCambio();
}

if(isset($_POST['AperturaCaja'])){
    $sistema->AperturaCaja();
}

if(isset($_POST['CierreCaja'])){
    $sistema->CierreCaja();
}

if(isset($_POST['CajaChicaOperacion'])){
    $sistema->CajaChica();
}