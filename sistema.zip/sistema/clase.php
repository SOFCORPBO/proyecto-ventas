<?php
/*
|--------------------------------------------------------------------------|
| Definir constantes si no existen
|--------------------------------------------------------------------------|
*/
if(!defined('DS')) define('DS', DIRECTORY_SEPARATOR);
if(!defined('SISTEMA')) define('SISTEMA', __DIR__ . DS);
if(!defined('CLASE')) define('CLASE', SISTEMA . 'clase' . DS);

/*
|--------------------------------------------------------------------------|
| Carga automática de Clases (PHP 7/8 compatible)
|--------------------------------------------------------------------------|
*/
spl_autoload_register(function ($NombreClase) {
    $ruta = CLASE . strtolower($NombreClase) . '.clase.php';
    if (file_exists($ruta)) {
        require_once $ruta;
    }
});

/*
|--------------------------------------------------------------------------|
| Instanciar Clases
|--------------------------------------------------------------------------|
*/
$db             = new Conexion();
$usuario        = new Usuario();
$enlace         = new Enlace();
$sistema        = new Sistema();
$Vendedor       = new Vendedor();
$notificacion   = new Notificacion();
$EstadoCuenta   = new EstadoCuenta();
$ProductosClase = new Productos();
$CajaDeVenta    = new Venta();
